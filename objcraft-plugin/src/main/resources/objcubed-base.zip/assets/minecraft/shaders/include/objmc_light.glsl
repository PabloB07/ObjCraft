//objmc
//https://github.com/Godlander/objmc

//default lighting
if (isCustom == 0) {
#ifndef EMISSIVE
    color *= lightColor;
#endif
#ifdef PER_FACE_LIGHTING
    color *= (gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack);
#else
    color *= vertexColor;
#endif
#ifdef ENTITY
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
    color *= ColorModulator;
#endif
}
//custom lighting
else {
    // Color behavior is independent of lighting, including emissive armor
    // faces and the whole-model No Shadow option.
#ifdef ENTITY
    color *= overlayColor;
#endif
    if (noshadow == 0) {
    //normal from position derivatives
    vec3 normal = normalize(cross(objmcPosDx, objmcPosDy));
    if (dot(ocSmoothNormal,ocSmoothNormal) > 1e-10) {
        // Match the visible side used by the legacy derivative normal on two-sided faces.
        vec3 smoothNormal = normalize(ocSmoothNormal);
        normal = dot(normal,smoothNormal) < 0.0 ? -smoothNormal : smoothNormal;
    }

    //block lighting
#ifdef BLOCK
    float vertical = sign(normal.y) * 0.3 + 0.7;
    float horizontal = abs(normal.z) * 0.25 + 0.5;
    float brightness = mix(horizontal, vertical, abs(normal.y));
    color *= vec4(vec3(brightness), 1.0);
#endif

    //entity lighting
#ifdef ENTITY
    //flip normal z for gui (zx flip in vertex shader)
    if (isGUI == 1) normal.z *= -1;
#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
    color *= minecraft_mix_light(Light0_Direction, Light1_Direction, normal, vec4(1.0));
#endif
#endif

    }
    // Ambient (2) still receives world light. Only explicit glow (1) bypasses it.
    if (noshadow != 1) color *= lightColor;
}
